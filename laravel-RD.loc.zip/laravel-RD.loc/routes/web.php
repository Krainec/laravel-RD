<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('numbers.index');
});
Auth::routes();

Route::group(['middleware' => 'auth'], function(){
    Route::match(['get', 'post'], 'list', 'NumbersController@index')->name('numbers.index');
    Route::get('create', 'NumbersController@create')->name('numbers.create');
    Route::post('store', 'NumbersController@store')->name('numbers.store');
    Route::get('edit/{id}', 'NumbersController@edit')->name('numbers.edit');
    Route::put('up/{id}/update', 'NumbersController@update')->name('numbers.update');
    Route::delete('delete/{id}/destroy', 'NumbersController@destroy')->name('numbers.destroy');
    Route::match(['get', 'post'], 'search', 'NumbersController@result')->name('numbers.result');
});


