<?php

namespace App\Http\Controllers;

use App\Http\Requests\createNumberRequest;
use Illuminate\Http\Request;
use App\Number;
use Auth;

//use Illuminate\Foundation\Auth\AuthenticatesUsers;
//use App\Http\Requests\createNumberRequest;

class NumbersController extends Controller
{
    //use ValidatesRequests;
    public function __construct()
    {
//        if (!Auth::user()->hasRole('admin')) {
//            return redirect('/');
//        }
    }

    public function index()
    {

        $id = Auth::user()->id;

        $numbers = Number::select()->where('user_id', $id)->orderBy('created_at', 'desc')->paginate(4);

        return view('list.index', ['numbers' => $numbers]);

    }



    public function create()
    {
        return view('list.create');
    }

    public function store(Request $request)
    {
//        dd($request->user()->id);
        $this->validate($request, [
            'name' => 'required|min:6',
            'number' => 'required|numeric|min:6',
            'email' => 'required|string|email|max:255'
        ]);
//        dd($request->all());
        //Number::create($request->all());
        $number = new Number;
        $number->user_id = $request->user()->id;
        $number->name = $request->get('name');
        $number->number = $request->get('number');
        $number->email = $request->get('email');

        $number->save();
        return redirect()->route('numbers.index');
    }

    public
    function edit($id)
    {
//        dd($id);
        $editNumber = Number::find($id);
        return view('list.edit', ['number' => $editNumber]);
    }

    public
    function update(Request $request, $id)
    {
        $this->validate($request,
            [
                'name' => 'required|min:6',
                'number' => 'required|numeric|min:6',
                'email' => 'required|string|email|max:255'
            ]);
        $number = Number::find($id);
        $number->fill($request->all());
        $number->save();
        return redirect()->route('numbers.index');
    }

    public function destroy($id)
    {
        Number::find($id)->delete();
        return redirect()->route('numbers.index');
    }

    public function search(Request $request)
    {
        $name = $request->get('name');
//        dd($name);
        $test = Number::select()->where('name', $name)->get();
//
        return route('numbers.result', ['all' => $test]);
        return view('numbers.result');
//        return redirect()->route('numbers.index')->with('all',$search);

    }
    public function result(Request $request)
    {
        if ($request->get('name')|| $request->get('number')||$request->get('email')) {

            $id = Auth::user()->id;
            $numbers = Number::select()->where('user_id', $id);
            if($request->get('name')){

                $name = $request->get('name');
                $numbers->where('name', 'like' , '%'.$name.'%');


            };
            if($request->get('number')){
                $number = $request->get('number');
                $numbers->where('number', 'like' , '%'.$number.'%');
            };
            if($request->get('email')){
                $email = $request->get('email');
                $numbers->where('email', 'like', '%'.$email.'%');
            };
//            dd($numbers);

            $numbers = $numbers->get();
            //$numbers = Number::select()->where('user_id', $id)->where('name', $name)->get();
            return view('list.result', ['numbers' => $numbers]);
        } else {
            //dd(1);
            return redirect()->route('numbers.index');
        }
    }
}
