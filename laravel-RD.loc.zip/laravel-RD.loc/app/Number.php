<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Number extends Model
{
    protected $fillable = [
        'user_id',
        'name',
        'number',
        'email'
    ];
}
