<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row align-self-center">
            <div class="col-12">
                <br>
                <div class="wrap__border">
                    <h4 class="h4 title__border">Поиск</h4>
                    <?php echo Form::open(['route' => 'numbers.result', 'id' => 'form__search', 'class' => 'form__search form-inline']); ?>

                    <input type="hidden" name="search" value="search_number">
                    <div class="form-group justify-content-between">
                        <div class="form-group mb-3">
                            <label for="search_fio" class="">ФИО</label>
                            <input type="text" name="name" id="search_fio" class="form-control" value="">
                        </div>
                        <div class="form-group mb-3">
                            <label for="search_number" class="">Номер</label>
                            <input type="text" name="number" id="search_number" class="form-control" value="">
                        </div>
                        <div class="form-group mb-3">
                            <label for="search_email" class="">Email</label>
                            <input type="text" name="email" id="search_email" class="form-control"
                                   value="">
                        </div>
                        <div class="form-group mb-3">
                            <button class="btn btn-success mb-2 form__submit">Поиск</button>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
                <br>
                <div class="list">
                    <table class="table table-bordered">
                        <thead>
                        <tr class="table-active row">
                            <th class="col-6 col-sm-4">ФИО</th>
                            <th class="col-6 col-sm-3">Телефон</th>
                            <th class="col-6 col-sm-4">Email</th>
                            <th class="col-6 col-sm-1"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if( isset($all) ): ?>
                            <?php echo e(var_dump($all)); ?>

                        <?php endif; ?>
                        <?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="row">
                                <td class="col-6 col-sm-4 col-xs-4"><?php echo e($number->name); ?></td>
                                <td class="col-6 col-sm-3 col-xs-3"><?php echo e($number->number); ?></td>
                                <td class="col-6 col-sm-4 col-xs-3"><?php echo e($number->email); ?></td>
                                <td class="col-6 col-sm-1 col-xs-2 icons ">
                                    <a href="<?php echo e(route('numbers.edit', $number->id)); ?>">
                                        <i class="far fa-edit"></i>
                                    </a>
                                    <?php echo Form::open(['method' => 'DELETE', 'route'=>['numbers.destroy', $number->id]]); ?>

                                    <button onclick="return confirm('Are you sure?')" class="delete">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <br>
                    <div class="pagination justify-content-center">
                        <?php echo e($numbers->links()); ?>

                    </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>