<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <br><br>
        <h1 class="text-center">Записная книжка</h1>
        <br>
        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="wrap__border">
                    <h4 class="h4 title__border">Вход</h4>
                    <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                        <?php echo csrf_field(); ?>
                        <br>
                        <div class="">
                            <div class="">
                                <input id="email" type="email"
                                       class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"
                                       value="<?php echo e(old('email')); ?>" required autofocus placeholder="Email">
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <br>
                        <div class="">
                            <div class="">
                                <input id="password" type="password"
                                       class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                       name="password" required placeholder="Пароль">
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <br>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Войти')); ?>

                            </button>
                        </div>
                        <div class="text-center">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">Создать аккаунт</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>