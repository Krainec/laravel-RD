@extends('layout')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="wrap__border">
                    <h4 class="h4 title__border">Поиск</h4>
                    @include('errors')
                    {!! Form::open(['route' => [ 'numbers.update', $number->id ], 'method' => 'PUT', 'class' => 'form-inline']) !!}

                    <div class="form-group mb-2">
                        <label for="search_fio" class="">ФИО</label>
                        <input type="text" name="name" id="search_fio" class="form-control" value="{{$number->name}}">
                    </div>
                    <div class="form-group mb-2">
                        <label for="search_number" class="">Номер</label>
                        <input type="text" name="number" id="search_number" class="form-control"
                               value="{{$number->number}}">
                    </div>
                    <div class="form-group mb-2">
                        <label for="search_email" class="">Email</label>
                        <input type="text" name="email" id="search_email" class="form-control"
                               value="{{$number->email}}">
                    </div>
                    <div class="center mx-auto">
                        <button class="btn btn-success">Сохранить</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
@endsection