@extends('layout')
@section('navbar')
@endsection
@section('content')
    <div class="container">
        <br><br>
        <h1 class="text-center">Записная книжка</h1>
        <br>
        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="wrap__border">
                    <h4 class="h4 title__border">Вход</h4>
                    <form method="POST" action="{{ route('login') }}" aria-label="{{ __('Login') }}">
                        @csrf
                        <br>
                        <div class="">
                            <div class="">
                                <input id="email" type="email"
                                       class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email"
                                       value="{{ old('email') }}" required autofocus placeholder="Email">
                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <br>
                        <div class="">
                            <div class="">
                                <input id="password" type="password"
                                       class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}"
                                       name="password" required placeholder="Пароль">
                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <br>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Войти') }}
                            </button>
                        </div>
                        <div class="text-center">
                            <a class="nav-link" href="{{ route('register') }}">Создать аккаунт</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
